@extends('layouts.app')

@section('title', 'Beranda')

@section('content')
    <h1>Selamat Datang di UD. Lestari Batako</h1>
    <p>Kami menyediakan batako berkualitas dan material bangunan lainnya.</p>
@endsection
