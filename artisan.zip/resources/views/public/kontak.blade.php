@extends('layouts.public')

@section('content')
<div class="container py-6">
    <h1>Kontak</h1>
    <p>Hubungi kami di:</p>
    <ul>
        <li>Telepon: 0812-3456-7890</li>
        <li>Email: info@lestari-batako.local</li>
        <li>Alamat: Jl. Contoh No.1, Kota</li>
    </ul>
</div>
@endsection
