@extends('layouts.app')

@section('content')
    @includeWhen(true, 'dashboard.index')
@endsection
