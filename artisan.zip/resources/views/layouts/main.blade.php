@extends('layouts.app')

@section('content')
	{{-- Deprecated: use layouts.app directly --}}
@endsection