<?php $__env->startSection('content'); ?>
<div class="page-container">


        <section class="dashboard-header">
            <h1>Daftar Pengiriman</h1>
            <p>Manajemen pengiriman UD. Lestari Batako</p>
        </section>

        
        <div class="pt-">
            <?php $__env->startComponent('components.breadcrumb'); ?>
                <?php $__env->slot('breadcrumbs', [
                    ['name' => 'Pengiriman', 'url' => route('pengiriman.index')]
                ]); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        
        <div class="row justify-content-between align-items-center mb-">
            <div class="col-auto">
                <h4 class="fw-bold text-primary"><i class="bi bi-truck"></i>Data Pengiriman</h4>
            </div>
        </div>

        
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill text-success me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger mt-3 shadow-sm">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><i class="bi bi-exclamation-circle-fill text-danger me-2"></i><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        
        <div class="table-industrial-wrapper">
            <div class="p-3">
                <div class="table-responsive">
                    <table class="table custom-table striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pelanggan</th>
                                <th>Alamat Pengiriman</th>
                                <th>Tanggal Pengiriman</th>
                                <th>Jasa Kirim</th>
                                <th>No Resi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pengirimans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengiriman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="text-center">
                                <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pengiriman->pesanan->pelanggan->nama); ?></td>
                                <td><?php echo e($pengiriman->alamat_pengiriman); ?></td>
                                <td>
                                    <?php echo e($pengiriman->tanggal_pengiriman ? $pengiriman->tanggal_pengiriman->format('d M Y') : '-'); ?>

                                </td>
                                <td><?php echo e($pengiriman->jasa_kurir ?? '-'); ?></td>
                                <td><?php echo e($pengiriman->no_resi ?? '-'); ?></td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">

                                        
                                        <a href="<?php echo e(route('pengiriman.show', $pengiriman->id_pengiriman)); ?>"
                                           class="btn btn-primary btn-sm rounded-circle"
                                           data-bs-toggle="tooltip" title="Lihat Detail">
                                            <i class="bi bi-eye"></i>
                                        </a>


                                        
                                        <a href="<?php echo e(route('pengiriman.edit', $pengiriman->id_pengiriman)); ?>"
                                           class="btn btn-warning btn-sm rounded-circle"
                                           data-bs-toggle="tooltip" title="Edit">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>

                                        
                                        <form action="<?php echo e(route('pengiriman.destroy', $pengiriman->id_pengiriman)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus pengiriman ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm rounded-circle"
                                                    data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>

                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted fst-italic">Belum ada data pengiriman.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer text-end small text-muted bg-white">
                UD Lestari Batako &copy; <?php echo e(date('Y')); ?>

            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(el => new bootstrap.Tooltip(el));
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/pengiriman/dashboard_pengiriman.blade.php ENDPATH**/ ?>