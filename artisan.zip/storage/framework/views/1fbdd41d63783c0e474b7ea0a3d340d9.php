<?php $__env->startSection('content'); ?>

<div class="page-container p-fluid">


        
        <section class="dashboard-header">
            <h1>Daftar Pelanggan</h1>
            <p>Manajemen pelanggan UD. Lestari Batako</p>
        </section>

        
        <div class="">
            <?php $__env->startComponent('components.breadcrumb'); ?>
                <?php $__env->slot('breadcrumbs', [
                    ['name' => 'Pelanggan', 'url' => route('pelanggan.index')],
                ]); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        
        <div class="row justify-content-between align-items-center mb-4">
            <div class="col-auto">
                <h4 class="fw-bold text-primary">
                    <i class="bi bi-people-fill me-2"></i>Daftar Pelanggan
                </h4>
            </div>
            <div class="col-auto">
                <a href="<?php echo e(route('pelanggan.create')); ?>" class="btn btn-primary shadow-sm d-flex align-items-center gap-1">
                    <i class="bi bi-plus-circle-fill"></i> Tambah Pelanggan
                </a>
            </div>
        </div>

        
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        
        <div class="table-industrial-wrapper">
            <div class="page-container">
                <div class="table-responsive">
                    <table class="table custom-table">
                        <thead>
                            <tr>
                                <th><center>No</center></th>
                                <th><center>Nama</center></th>
                                <th><center>Email</center></th>
                                <th><center>No HP</center></th>
                                <th><center>Alamat</center></th>
                                <th><center>Dibuat</center></th>
                                <th><center>Aksi</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $KurirData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pelanggan->nama); ?></td>
                                <td><?php echo e($pelanggan->email ?? '-'); ?></td>
                                <td><?php echo e($pelanggan->no_hp ?? '-'); ?></td>
                                <td><?php echo e($pelanggan->alamat ?? '-'); ?></td>
                                <td><?php echo e($pelanggan->created_at->format('d M Y H:i')); ?></td>
                                <td>
                                    <div class="d-flex justify-content-center gap-2">
                                        
                                        <a href="<?php echo e(route('pelanggan.edit', $pelanggan->id_pelanggan)); ?>"
                                           class="btn btn-sm btn-warning btn-icon"
                                           data-bs-toggle="tooltip" title="Edit Pelanggan">
                                            <i class="bi bi-pencil-fill"></i>
                                        </a>

                                        
                                        <a href="<?php echo e(route('pesanan.create', ['id_pelanggan' => $pelanggan->id_pelanggan])); ?>"
                                           class="btn btn-sm btn-success btn-icon"
                                           data-bs-toggle="tooltip" title="Atur Pesanan">
                                            <i class="bi bi-cart-check-fill"></i>
                                        </a>

                                        
                                        <form action="<?php echo e(route('pelanggan.destroy', $pelanggan->id_pelanggan)); ?>" method="POST"
                                              onsubmit="return confirm('Yakin hapus pelanggan ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                    class="btn btn-sm btn-danger btn-icon"
                                                    data-bs-toggle="tooltip" title="Hapus Pelanggan">
                                                <i class="bi bi-trash-fill"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">Belum ada pelanggan.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(el => new bootstrap.Tooltip(el));
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/pelanggan/dashboard_pelanggan.blade.php ENDPATH**/ ?>