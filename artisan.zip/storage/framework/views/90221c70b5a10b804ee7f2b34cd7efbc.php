<?php $__env->startSection('content'); ?>
<div class="page-container">
<div class="">
        <?php $__env->startComponent('components.breadcrumb'); ?>
                <?php $__env->slot('breadcrumbs', [
                    ['name' => 'Pengiriman', 'url' => route('pengiriman.index')],
                    ['name' => 'Tambah Pengiriman', 'url' => route('pelanggan.create')]
                ]); ?>
            <?php echo $__env->renderComponent(); ?>
            </div>
    <h4 class="mb- fw-bold text-primary">Atur Pengiriman</h4>
    <div class="card custom-card max-w-900">
        <div class="card-body p-0">
            <form action="<?php echo e(route('pengiriman.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_pesanan" value="<?php echo e($pesanan->id_pesanan); ?>">
                <input type="hidden" name="id_pelanggan" value="<?php echo e($pesanan->pelanggan->id_pelanggan); ?>">

                <div class="mb-4">
                    <label for="alamat_pengiriman" class="form-label fw-semibold">Alamat Pengiriman *</label>
                    <textarea class="form-control form-textarea" id="alamat_pengiriman" name="alamat_pengiriman" rows="4" required><?php echo e($pesanan->pelanggan->alamat); ?></textarea>
                </div>

                <div class="mb-4">
                    <label for="tanggal_pengiriman" class="form-label fw-semibold">Tanggal Pengiriman *</label>
                    <input type="date" class="form-control" id="tanggal_pengiriman" name="tanggal_pengiriman" required>
                </div>

                <div class="mb-4">
                    <label for="jasa_kurir" class="form-label fw-semibold">Jasa Kurir *</label>
                    <input type="text" class="form-control" id="jasa_kurir" name="jasa_kurir" required placeholder="Masukkan nama jasa kurir">
                </div>

                <div class="mb-4">
                    <label for="no_resi" class="form-label fw-semibold">No Resi</label>
                    <input type="text" class="form-control" id="no_resi" name="no_resi" placeholder="Masukkan nomor resi">
                </div>

                <div class="d-flex justify-content-end gap-2 mt-5 pt-3">
                    <a href="<?php echo e(route('pesanan.index')); ?>" class="btn btn-secondary-custom">
                        <i class="bi bi-arrow-left-circle me-2"></i>Batal
                    </a>
                    <button type="submit" class="btn btn-primary-custom">
                        <i class="bi bi-save me-2"></i>Simpan Pengiriman
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/pengiriman/create_pengiriman.blade.php ENDPATH**/ ?>