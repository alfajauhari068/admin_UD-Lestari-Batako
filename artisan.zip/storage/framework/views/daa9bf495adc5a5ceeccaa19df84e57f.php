<div class="stats-grid">
    <div class="stat-card">
        <i class="bi bi-box"></i>
        <div>
            <h6>Total Produk</h6>
            <div class="value"><?php echo e($totalProduk ?? 0); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <i class="bi bi-exclamation-triangle"></i>
        <div>
            <h6>Stok Kritis</h6>
            <div class="value"><?php echo e($produkKritis ?? 0); ?></div>
        </div>
    </div>

    <div class="stat-card">
        <i class="bi bi-cart-check"></i>
        <div>
            <h6>Pesanan Hari Ini</h6>
            <div class="value"><?php echo e($pesananHariIni ?? 0); ?></div>
        </div>
    </div>
</div>
<?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/dashboard/partials/stats.blade.php ENDPATH**/ ?>