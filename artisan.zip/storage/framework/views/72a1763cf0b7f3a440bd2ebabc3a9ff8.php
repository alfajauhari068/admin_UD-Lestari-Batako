<?php $__env->startSection('content'); ?>
<div class="page-container p-fluid" >
        <div class="mt-4">
            <?php $__env->startComponent('components.breadcrumb'); ?>
                    <?php $__env->slot('breadcrumbs', [
                        ['name' => 'Produksi', 'url' => route('produksi.index')],
                        ['name' => 'Tambah Produksi', 'url' => route('produksi.create')]
                    ]); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
    <h2 class="mb-5 fw-bold text-primary">Tambah Produksi</h2>
    <form action="<?php echo e(route('produksi.store')); ?>" method="POST" class="card custom-card p-5">
    <?php echo csrf_field(); ?>

    
    <div class="mb-4">
        <label for="id_produk" class="form-label">Produk *</label>
        <select class="form-control <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_produk" name="id_produk" required>
            <option value="">Pilih Produk</option>
            <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($produk->id_produk); ?>"><?php echo e($produk->nama_produk); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
        <label for="kriteria_gaji" class="form-label">Kriteria Gaji *</label>
        <textarea class="form-control form-textarea <?php $__errorArgs = ['kriteria_gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kriteria_gaji" name="kriteria_gaji" required
              placeholder="Jelaskan kriteria gaji — deskripsi kapan karyawan berhak menerima gaji berdasarkan pencapaian produksi"><?php echo e(old('kriteria_gaji')); ?></textarea>
        <?php $__errorArgs = ['kriteria_gaji'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
         <label for="gaji_per_unit" class="form-label">Gaji Per Unit *</label>
         <input type="number" class="form-control <?php $__errorArgs = ['gaji_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             id="gaji_per_unit" name="gaji_per_unit" value="<?php echo e(old('gaji_per_unit')); ?>" required
             placeholder="Masukkan gaji per unit">
        <?php $__errorArgs = ['gaji_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
         <label for="jumlah_per_unit" class="form-label">Jumlah Per Unit *</label>
         <input type="number" class="form-control <?php $__errorArgs = ['jumlah_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             id="jumlah_per_unit" name="jumlah_per_unit" value="<?php echo e(old('jumlah_per_unit', 100)); ?>" required
             placeholder="Masukkan patokan jumlah per unit (contoh: 100)">
        <?php $__errorArgs = ['jumlah_per_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="d-flex justify-content-end gap-2 mt-5 pt-3">
        <a href="<?php echo e(route('produksi.index')); ?>" class="btn btn-secondary btn-secondary-custom">
            <i class="bi bi-arrow-left-circle me-2"></i>Batal
        </a>
        <button type="submit" class="btn btn-primary btn-primary-custom">
            <i class="bi bi-save me-2"></i>Simpan
        </button>
    </div>
</form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/produksi/create_produksi.blade.php ENDPATH**/ ?>