<?php $__env->startSection('content'); ?>
    <div class="page-container">
        

        <section class="dashboard-header">
            <h1>Daftar Pesanan</h1>
            <p>Manajemen pesanan UD. Lestari Batako</p>
        </section>
        
        
        <div class="">
            <?php $__env->startComponent('components.breadcrumb'); ?>
                <?php $__env->slot('breadcrumbs', [
                    ['name' => 'Pesanan', 'url' => route('pesanan.index')]
                ]); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        
        <div class="row justify-content-between align-items-center mb-">
            <div class="col-auto">
                <h4 class="fw-bold text-primary"><i class="bi bi-cart"></i>Data Pesanan</h4>
            </div>
            <div class="col-auto">
                <div class="d-flex align-items-center gap-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export pesanan')): ?>
                        <a href="<?php echo e(route('pesanan.export.csv')); ?>" class="btn btn-outline-secondary btn-sm">Export CSV</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('pesanan.create')); ?>" class="btn btn-primary rounded-circle shadow-sm d-flex justify-content-center align-items-center p-2"
                       data-bs-toggle="tooltip" title="Tambah Pesanan">
                        <i class="bi bi-plus-circle fs-4"></i>
                    </a>
                </div>
            </div>
        </div>

        
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill text-success me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger mt-3 shadow-sm">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><i class="bi bi-exclamation-circle-fill text-danger me-2"></i><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        
        <div class="table-industrial-wrapper">
            <div class="p-3">
                <div class="table-responsive">
                    <table class="table custom-table striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>ID Pesanan</th>
                                <th>Pelanggan</th>
                                <th>Catatan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center align-middle"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($pesanan->id_pesanan); ?></td>
                                <td><?php echo e($pesanan->pelanggan->nama); ?></td>
                                <td><?php echo e($pesanan->catatan ?? '-'); ?></td>
                                <td class="text-center align-middle">
                                    <div class="d-flex justify-content-center gap-2">

                                        
                                        <a href="<?php echo e(route('pesanan.detail', $pesanan->id_pesanan)); ?>" 
                                           class="btn btn-primary btn-sm btn-icon" 
                                           data-bs-toggle="tooltip" title="Lihat Detail Pesanan">
                                            <i class="bi bi-eye"></i>
                                        </a>

                                        
                                        <a href="<?php echo e(route('pengiriman.create', $pesanan->id_pesanan)); ?>" 
                                           class="btn btn-success btn-sm btn-icon" 
                                           data-bs-toggle="tooltip" title="Atur Pengiriman">
                                            <i class="bi bi-truck"></i>
                                        </a>

                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted fst-italic">Belum ada pesanan.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer text-end small text-muted bg-white">
                UD Lestari Batako &copy; <?php echo e(date('Y')); ?>

            </div>
        </div>
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(el => new bootstrap.Tooltip(el));
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/pesanan/dashboard_pesanan.blade.php ENDPATH**/ ?>