<ul class="list-group list-group-flush">
    <?php $__empty_1 = true; $__currentLoopData = $historyProduksiKaryawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li class="list-group-item d-flex justify-content-between align-items-center">
        <span><?php echo e(optional($h->karyawan)->nama ?? 'N/A'); ?> – <?php echo e(optional(optional($h->produksi)->produk)->nama_produk ?? 'N/A'); ?></span>
        <span class="badge bg-primary"><?php echo e($h->tanggal_produksi); ?></span>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li class="list-group-item text-center text-muted">Belum ada history</li>
    <?php endif; ?>
</ul>
<ul class="list-group list-group-flush dashboard-history-list">
    <?php $__empty_1 = true; $__currentLoopData = $historyProduksiKaryawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li class="list-group-item d-flex justify-content-between align-items-center">
        <div class="history-info">
            <div class="history-user">
                <?php echo e(optional($h->karyawan)->nama ?? 'N/A'); ?>

            </div>
            <div class="history-meta text-muted">
                <?php echo e(optional(optional($h->produksi)->produk)->nama_produk ?? 'N/A'); ?>

            </div>
        </div>

        <span class="badge badge-warning">
            <?php echo e($h->tanggal_produksi); ?>

        </span>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li class="list-group-item text-center text-muted py-4">
        Belum ada history produksi
    </li>
    <?php endif; ?>
</ul>
<?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/dashboard/partials/history.blade.php ENDPATH**/ ?>