<?php $__env->startSection('content'); ?>
<div class="d-flex">
    

    
    <div class="container-fluid p-5 py-5" style="min-height: 100vh; background: #f9f9f9;">
        
        
        <section class="dashboard-header">
            <h1>Daftar Produksi</h1>
            <p>Manajemen produksi UD. Lestari Batako</p>
        </section>

        
        <div class="">
            <?php $__env->startComponent('components.breadcrumb'); ?>
                <?php $__env->slot('breadcrumbs', [
                    ['name' => 'Produksi', 'url' => route('produksi.index')]
                ]); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        
        <div class="row justify-content-between align-items-center mb-4">
            <div class="col-auto">
                <h4 class="fw-bold text-primary">
                    <i class="bi bi-tools"></i>Daftar Produksi
                </h4>
            </div>
            <div class="col-auto">
                     <a href="<?php echo e(route('produksi.create')); ?>"
                   class="btn btn-primary d-flex align-items-center gap-1 shadow-sm">
                    <i class="bi bi-plus-circle"></i> Tambah Produksi
                </a>
            </div>
        </div>

        
        <div class="card shadow-sm border-0" style="border-radius: 12px;">
            <div class="card-body">

                
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                        <i class="bi bi-check-circle-fill me-2 text-success"></i><?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger shadow-sm">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="bi bi-exclamation-circle-fill text-danger me-2"></i><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                
                <div class="table-industrial-wrapper">
                    <table class="table table-industrial striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Produksi</th>
                                <th>Kriteria Gaji</th>
                                <th>Gaji Per Unit</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $produksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="text-center">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($produksi->produk->nama_produk ?? 'N/A'); ?></td>
                                    <td class="text-start"><?php echo e($produksi->kriteria_gaji); ?></td>
                                    <td>Rp<?php echo e(number_format((float) $produksi->gaji_per_unit, 0, ',', '.')); ?></td>
                                    <td>
                                        <div class="d-flex justify-content-center gap-2">
                                            
                                            <a href="<?php echo e(route('produksi.edit', $produksi->id_produksi)); ?>"
                                               class="btn btn-sm btn-warning rounded-circle"
                                               data-bs-toggle="tooltip" title="Edit Produksi"
                                               style="width: 32px; height: 32px;">
                                                <i class="bi bi-pencil"></i>
                                            </a>

                                            
                                            <form action="<?php echo e(route('produksi.destroy', $produksi->id_produksi)); ?>"
                                                  method="POST" onsubmit="return confirm('Yakin ingin menghapus produksi ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                        class="btn btn-sm btn-danger rounded-circle"
                                                        data-bs-toggle="tooltip" title="Hapus Produksi"
                                                        style="width: 32px; height: 32px;">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted fst-italic">
                                        Belum ada data produksi.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            
            <div class="card-footer text-end small text-muted bg-white">
                UD Lestari Batako &copy; <?php echo e(date('Y')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/produksi/dashboard_produksi.blade.php ENDPATH**/ ?>