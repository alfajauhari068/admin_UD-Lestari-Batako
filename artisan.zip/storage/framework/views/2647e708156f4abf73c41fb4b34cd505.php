

<?php $__env->startSection('content'); ?>
<div class="page-container p-fluid">
    <div class="mt-4">
        <?php $__env->startComponent('components.breadcrumb'); ?>
            <?php $__env->slot('breadcrumbs', [
                ['name' => 'Produksi Karyawan Tim', 'url' => route('tim_produksi.index')],
                ['name' => 'Tambah Data', 'url' => route('tim_produksi.index')]
            ]); ?>
        <?php echo $__env->renderComponent(); ?>
    </div>
    
    <h2 class="mb-5 fw-bold text-primary">Tambah Data Produksi Karyawan Tim</h2>
    <form action="<?php echo e(route('tim_produksi.store')); ?>" method="POST" class="card custom-card p-5 mx-auto max-w-900">
        <?php echo csrf_field(); ?>
        
        
        <div class="mb-4">
                <label for="id_produksi" class="form-label">Nama Produksi *</label>
                <select class="form-control <?php $__errorArgs = ['id_produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_produksi" name="id_produksi" required>
                <option value="">Pilih Produksi</option>
                <?php $__currentLoopData = $produksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($produksi->id_produksi); ?>"><?php echo e($produksi->produk->nama_produk ?? 'N/A'); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-4">
                <label for="id_karyawan" class="form-label">Nama Karyawan (Pilih beberapa) *</label>
                <select class="form-control form-multiselect <?php $__errorArgs = ['id_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_karyawan" name="id_karyawan[]" multiple required>
                <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($karyawan->id_karyawan); ?>"><?php echo e($karyawan->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small class="text-muted">Tekan Ctrl (Windows) atau Cmd (Mac) untuk memilih beberapa karyawan sekaligus.</small>
            <?php $__errorArgs = ['id_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php if($errors->has('id_karyawan.*')): ?>
                <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;">Beberapa pilihan karyawan tidak valid.</div>
            <?php endif; ?>
        </div>

        
        <div class="mb-4">
                 <label for="tanggal_produksi" class="form-label">Tanggal Produksi *</label>
                 <input type="date" class="form-control <?php $__errorArgs = ['tanggal_produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tanggal_produksi" name="tanggal_produksi" required>
            <?php $__errorArgs = ['tanggal_produksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-4">
                 <label for="jumlah_unit" class="form-label">Jumlah Unit *</label>
                 <input type="number" class="form-control <?php $__errorArgs = ['jumlah_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah_unit" name="jumlah_unit" required min="1">
                 <small class="form-note">Masukkan jumlah unit yang dikontribusikan oleh karyawan ini untuk produksi tim pada tanggal tersebut.</small>
            <?php $__errorArgs = ['jumlah_unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback d-block" style="color: #DC2626; margin-top: 0.5rem;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="alert alert-info mt-4 mb-4">
            <strong><i class="bi bi-info-circle me-2"></i>Catatan Penting:</strong><br>
            <small>
                Gaji akan dihitung otomatis berdasarkan total unit tim, bukan individual.
                Satu tim produksi dalam 1 hari = 1 perhitungan gaji untuk semua anggota.
            </small>
        </div>

        
        <div class="d-flex justify-content-end gap-2 mt-5 pt-3">
            <a href="<?php echo e(route('tim_produksi.index')); ?>" class="btn btn-secondary btn-secondary-custom">
                <i class="bi bi-arrow-left-circle me-2"></i>Batal
            </a>
            <button type="submit" class="btn btn-primary btn-primary-custom">
                <i class="bi bi-save me-2"></i>Simpan
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/produksi_karyawan_tim/create.blade.php ENDPATH**/ ?>