<!-- filepath: d:\KULIAH\Semester4\Pemrograman FrameWork\ud_lestari-batako\resources\views\produk\form_edit_produk.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="page-container p-fluid">
         <div class="mt-4">
        <?php $__env->startComponent('components.breadcrumb'); ?>
                <?php $__env->slot('breadcrumbs', [
                    ['name' => 'Produk', 'url' => route('produk.index')],
                    ['name' => 'Edit Produks',]
                ]); ?>
            <?php echo $__env->renderComponent(); ?>
    </div>
        <h4 class="mt-4 fw-bold text-primary">Edit Produk</h4>
        <form 
        action="<?php echo e(route('produk.update', $produk->id_produk ?? $produk->id)); ?>" 
        method="POST" 
        enctype="multipart/form-data"
        class="card custom-card p-4 p-md-5 rounded-4 mx-auto max-w-900"
        >

    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <h4 class="fw-bold text-primary mb-5 text-center">Edit Produk</h4>

    
    <div class="mb-4">
        <label for="nama_produk" class="form-label">Nama Produk</label>
        <input type="text" id="nama_produk" name="nama_produk"
                class="form-control <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e(old('nama_produk', $produk->nama_produk)); ?>"
                placeholder="Masukkan nama produk" required>
        <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
        <label for="gambar_produk" class="form-label fw-semibold" style="color: #1E293B; font-size: 0.95rem;">Gambar Produk</label>
        <?php if($produk->gambar_produk): ?>
            <div class="mb-3">
                 <img src="<?php echo e(asset('storage/' . $produk->gambar_produk)); ?>" alt="Gambar Produk"
                     width="150" class="img-thumbnail shadow-sm rounded-lg">
            </div>
        <?php endif; ?>
        <input type="file" id="gambar_produk" name="gambar_produk"
               class="form-control <?php $__errorArgs = ['gambar_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*">
        <?php $__errorArgs = ['gambar_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
        <label for="harga_satuan" class="form-label">Harga Satuan</label>
        <input type="number" step="0.01" id="harga_satuan" name="harga_satuan"
               class="form-control <?php $__errorArgs = ['harga_satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               value="<?php echo e(old('harga_satuan', $produk->harga_satuan)); ?>"
               placeholder="Masukkan harga satuan" required>
        <?php $__errorArgs = ['harga_satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
        <label for="deskripsi_produk" class="form-label">Deskripsi Produk</label>
        <textarea id="deskripsi_produk" name="deskripsi_produk"
                  class="form-control form-textarea <?php $__errorArgs = ['deskripsi_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                  rows="4"
                  placeholder="Masukkan deskripsi produk"><?php echo e(old('deskripsi_produk', $produk->deskripsi_produk)); ?></textarea>
        <?php $__errorArgs = ['deskripsi_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
        <label for="stok_tersedia" class="form-label">Stok Tersedia</label>
        <input type="number" id="stok_tersedia" name="stok_tersedia"
               class="form-control <?php $__errorArgs = ['stok_tersedia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               value="<?php echo e(old('stok_tersedia', $produk->stok_tersedia)); ?>"
               placeholder="Masukkan jumlah stok" required>
        <?php $__errorArgs = ['stok_tersedia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="d-flex justify-content-end gap-2 mt-5 pt-3">
        <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-secondary btn-secondary-custom">
            <i class="bi bi-arrow-left-circle me-2"></i>Batal
        </a>
        <button type="submit" class="btn btn-primary btn-primary-custom">
            <i class="bi bi-save2 me-2"></i>Update
        </button>
    </div>
</form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/produk/form_edit_produk.blade.php ENDPATH**/ ?>