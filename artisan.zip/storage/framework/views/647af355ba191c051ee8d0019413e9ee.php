<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    
    <section class="dashboard-header mb-3">
        <h1>Daftar Produk</h1>
        <p class="text-muted">Manajemen produk UD. Lestari Batako</p>
    </section>

        
        <div class="mb-3">
            <?php $__env->startComponent('components.breadcrumb'); ?>
                <?php $__env->slot('breadcrumbs', [
                    ['name' => 'Produk', 'url' => route('produk.index')],
                ]); ?>
            <?php echo $__env->renderComponent(); ?>
        </div>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success shadow-sm">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        
        <div class=" d-flex justify-content-between align-items-center mb-3">
            <h3 class="fw-bold mb-0"><i class="bi bi-box-seam"></i>Data Produk</h3>
            <div class="d-flex gap-2">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export produk')): ?>
                    <a href="<?php echo e(route('produk.export.excel')); ?>" class="btn btn-outline-secondary btn-sm">Excel</a>
                    <a href="<?php echo e(route('produk.export.csv')); ?>" class="btn btn-outline-secondary btn-sm">CSV</a>
                    <a href="<?php echo e(route('produk.export.pdf')); ?>" class="btn btn-outline-secondary btn-sm">PDF</a>
                <?php endif; ?>
                <a href="<?php echo e(route('produk.create')); ?>"
                   class="btn btn-primary d-flex align-items-center gap-2 shadow-sm">
                    <i class="bi bi-plus-circle"></i>
                    Tambah
                </a>
            </div>
        </div>

        
        <section class="panel">

            <div class="panel-body">

                <div class="table-responsive">
                    <table class="table dashboard-table align-middle">
                        <thead>
                            <tr>
                                <?php
                                    $cols = [
                                        'id_produk' => 'No',
                                        'nama_produk' => 'Produk',
                                        'gambar_produk' => 'Gambar',
                                        'harga_satuan' => 'Harga',
                                        'stok_tersedia' => 'Stok',
                                        'created_at' => 'Dibuat',
                                    ];
                                    $currentSort = request('sort');
                                    $currentDir = request('direction', 'asc');
                                ?>
                                <?php $__currentLoopData = $cols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th>
                                        <?php if(in_array($key, ['gambar_produk'])): ?>
                                            <?php echo e($label); ?>

                                        <?php else: ?>
                                            <?php
                                                $nextDir = ($currentSort === $key && $currentDir === 'asc') ? 'desc' : 'asc';
                                                $query = array_merge(request()->query(), ['sort' => $key, 'direction' => $nextDir]);
                                                $url = url()->current() . '?' . http_build_query($query);
                                            ?>
                                            <a href="<?php echo e($url); ?>" class="text-decoration-none text-reset">
                                                <?php echo e($label); ?>

                                                <?php if($currentSort === $key): ?>
                                                    <i class="bi bi-arrow-<?php echo e($currentDir === 'asc' ? 'up' : 'down'); ?>-short"></i>
                                                <?php endif; ?>
                                            </a>
                                        <?php endif; ?>
                                    </th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $KurirData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>

                                <td class="fw-semibold">
                                    <?php echo e($produk->nama_produk); ?>

                                </td>

                                <td>
                                    <?php if($produk->gambar_produk && Storage::disk('public')->exists($produk->gambar_produk)): ?>
                                        <img src="<?php echo e(asset('storage/'.$produk->gambar_produk)); ?>" class="img-thumbnail" width="56">
                                    <?php elseif($produk->gambar_produk && file_exists(public_path($produk->gambar_produk))): ?>
                                        <img src="<?php echo e(asset($produk->gambar_produk)); ?>" class="img-thumbnail" width="56">
                                    <?php elseif($produk->gambar_produk && file_exists(public_path('gambar_produk/'.basename($produk->gambar_produk)))): ?>
                                        <img src="<?php echo e(asset('gambar_produk/'.basename($produk->gambar_produk))); ?>" class="img-thumbnail" width="56">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('gambar_produk/paving-block.png')); ?>" class="img-thumbnail" width="56">
                                    <?php endif; ?>
                                </td>

                                <td>
                                    Rp <?php echo e(number_format($produk->harga_satuan,0,',','.')); ?>

                                </td>

                                <td>
                                    <span class="badge <?php echo e($produk->stok_tersedia > 0 ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e($produk->stok_tersedia); ?>

                                    </span>
                                </td>

                                <td class="text-muted">
                                    <?php echo e(optional($produk->created_at)->format('d M Y')); ?>

                                </td>

                                <td class="text-center">
                                    <div class="d-inline-flex align-items-center gap-1">
                                        <a href="<?php echo e(route('produk.show', $produk->id_produk)); ?>"
                                           class="btn btn-sm btn-outline-primary"
                                           data-bs-toggle="tooltip" title="Lihat">
                                            <i class="bi bi-eye"></i>
                                        </a>

                                        <a href="<?php echo e(route('produk.edit', $produk->id_produk)); ?>"
                                           class="btn btn-sm btn-outline-warning"
                                           data-bs-toggle="tooltip" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>

                                        <form action="<?php echo e(route('produk.delete', $produk->id_produk)); ?>"
                                              method="POST"
                                              class="d-inline"
                                              onsubmit="return confirm('Hapus produk ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" data-bs-toggle="tooltip" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">
                                    Belum ada data produk
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                
                <div class="mt-3 d-flex justify-content-end">
                    <?php if(method_exists($KurirData, 'links')): ?>
                        <?php echo e($KurirData->withQueryString()->links()); ?>

                    <?php endif; ?>
                </div>

            </div>
        </section>

        
        <footer class="app-footer">
            &copy; <?php echo e(date('Y')); ?> UD. Lestari Batako
        </footer>

    
    <footer class="app-footer mt-4">
        &copy; <?php echo e(date('Y')); ?> UD. Lestari Batako
    </footer>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/produk/dashboard_produk.blade.php ENDPATH**/ ?>