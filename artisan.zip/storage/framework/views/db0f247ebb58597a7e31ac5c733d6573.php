<div class="table-responsive">
    <table class="table table-sm align-middle dashboard-table">
        <thead>
            <tr>
                
                <th>ID Pesanan</th>
                <th>Pelanggan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pesananTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                
                <td>
                <center>
                    <span class="fw-semibold text-primary">
                        #<?php echo e($p->id_pesanan); ?>

                    </span>
                </center>
                </td>
                <td>
                <center>
                    <span class="table-user">
                        <?php echo e($p->pelanggan->nama ?? '-'); ?>

                    </span>
                </center>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center text-muted py-4">
                    Tidak ada pesanan terbaru
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/dashboard/partials/pesanan-table.blade.php ENDPATH**/ ?>