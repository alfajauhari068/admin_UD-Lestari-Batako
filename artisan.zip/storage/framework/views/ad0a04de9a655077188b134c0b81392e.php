<div class="table-responsive">
    <table class="table table-sm align-middle dashboard-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Produksi</th>
                <th>Karyawan</th>
                <th class="text-end">Unit</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $produksiKaryawanTims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="text-muted"><center><?php echo e($loop->iteration); ?></center></td>
                <td>
                <center>
                    <span class="fw-medium">
                        <?php echo e(optional(optional($d->produksi)->produk)->nama_produk ?? 'N/A'); ?>

                    </span>
                </center>
                </td>
                <td>
                <center>
                    <span class="table-user">
                        <?php echo e(optional($d->karyawan)->nama ?? 'N/A'); ?>

                    </span>
                </center>
                </td>
                <td class="text-end">
                <center>
                    <span class="badge badge-info">
                        <?php echo e($d->jumlah_unit); ?> unit
                    </span>
                </center>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-center text-muted py-4">
                <center>
                    Belum ada data produksi
                </center>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/dashboard/partials/produksi-table.blade.php ENDPATH**/ ?>