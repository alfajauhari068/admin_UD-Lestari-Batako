<?php $__env->startSection('content'); ?>
<div class="page-container">
            <div class="mt-">
            <?php $__env->startComponent('components.breadcrumb'); ?>
                    <?php $__env->slot('breadcrumbs', [
                        ['name' => 'Pesanan', 'url' => route('pesanan.index')],
                        ['name' => 'Tambah Pesanan', 'url' => route('pesanan.create')]
                    ]); ?>
                <?php echo $__env->renderComponent(); ?>
            </div>
    <h4 class="mb- mt-2 fw-bold text-primary">Tambah Pesanan</h4>
    <div class="card custom-card max-w-900">
        <div class="card-body p-0">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i><?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger mb-4">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><i class="bi bi-exclamation-circle-fill me-2"></i><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('pesanan.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    
    <div class="mb-4">
        <label for="id_pelanggan" class="form-label fw-semibold">Pelanggan *</label>
        <select class="form-select form-control <?php $__errorArgs = ['id_pelanggan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id_pelanggan" name="id_pelanggan" required>
            <option value="" selected disabled>Pilih Pelanggan</option>
            <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pelanggan->id_pelanggan); ?>" <?php echo e(old('id_pelanggan') == $pelanggan->id_pelanggan ? 'selected' : ''); ?>>
                    <?php echo e($pelanggan->nama); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['id_pelanggan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="mb-4">
        <label for="catatan" class="form-label fw-semibold">Catatan</label>
        <textarea class="form-control form-textarea <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="catatan" name="catatan" rows="4" placeholder="Tambahkan catatan jika perlu"><?php echo e(old('catatan')); ?></textarea>
        <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="d-flex justify-content-end gap-2 mt-5 pt-3">
        <a href="<?php echo e(route('pesanan.index')); ?>" class="btn btn-secondary-custom">
            <i class="bi bi-arrow-left-circle me-2"></i>Batal
        </a>
        <button type="submit" class="btn btn-primary-custom">
            <i class="bi bi-save me-2"></i>Simpan Pesanan
        </button>
    </div>
</form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/pesanan/form_tambah_pesanan.blade.php ENDPATH**/ ?>