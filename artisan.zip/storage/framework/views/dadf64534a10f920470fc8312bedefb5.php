

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    
    <section class="dashboard-header mb-3">
            <div class="dashboard-header__title">
                <h1>Dashboard Admin</h1>
                <p>
                    <?php echo e(date('d M Y')); ?> ·
                    <span class="text-muted">
                        <?php echo e(Auth::user()->name ?? 'Admin'); ?>

                    </span>
                </p>
            </div>
        </section>

        
        <?php echo $__env->make('dashboard.partials.stats', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <section class="dashboard-grid">
            <div class="dashboard-col dashboard-col--left">
                <div class="panel">
                    <div class="panel-header">
                        <h3>Pesanan Terbaru</h3>
                    </div>
                    <div class="panel-body">
                        <?php echo $__env->make('dashboard.partials.pesanan-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="dashboard-col dashboard-col--right">
                <div class="panel">
                    <div class="panel-header">
                        <h3>Produksi Karyawan</h3>
                    </div>
                    <div class="panel-body">
                        <?php echo $__env->make('dashboard.partials.produksi-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </section>

        
        <section class="dashboard-history">
            <div class="panel">
                <div class="panel-header">
                    <h3>History Produksi</h3>
                </div>
                <div class="panel-body panel-body--scroll">
                    <?php echo $__env->make('dashboard.partials.history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </section>

    
    <footer class="app-footer mt-4">
        <span>&copy; <?php echo e(date('Y')); ?> UD. Lestari Batako</span>
    </footer>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/dashboard/index.blade.php ENDPATH**/ ?>