<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'UD. Lestari Batako')); ?></title>

    
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    
    <link href="<?php echo e(asset('assets/bootstrap-5.3.6-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/admin-industrial.css')); ?>">
    <style>
        :root{
            --bg-color: #ffffff;
            --text-color: #0f172a;
            --card-bg: #ffffff;
            --muted: #6b7280;
            --primary: #0ea5a3;
        }
        [data-theme="dark"]{
            --bg-color: #0b1220;
            --text-color: #e6eef6;
            --card-bg: #061021;
            --muted: #9ca3af;
            --primary: #06b6d4;
        }
        body{background-color:var(--bg-color); color:var(--text-color)}
    </style>

</head>

<?php
    $darkPref = false;
    if(auth()->check()){
        $darkPref = (bool) (auth()->user()->dark_mode ?? false);
    } else {
        $darkPref = session('dark_mode', false);
    }
?>

<body data-theme="<?php echo e($darkPref ? 'dark' : 'light'); ?>">

    
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="main-wrapper" style="margin-left:250px">

        
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-wrapper">
            <div class="page-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

    </div>

    
    <script src="<?php echo e(asset('assets/bootstrap-5.3.6-dist/js/bootstrap.bundle.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('js/dark-mode.js')); ?>"></script>

    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Expose simple loading helpers for components
            window.showTableLoading = function(id){
                const el = document.getElementById(id);
                if(el) el.classList.add('show-loading');
            };
            window.hideTableLoading = function(id){
                const el = document.getElementById(id);
                if(el) el.classList.remove('show-loading');
            };
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl)
            })
        });
    </script>

</body>
</html>
<?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/layouts/app.blade.php ENDPATH**/ ?>