<?php $__env->startSection('content'); ?>
<div class="container py-5" style="min-height: 100vh;">

    
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-header bg-primary text-white text-center rounded-top-4">
                    <h2 class="fw-bold mb-0">Detail Produk</h2>
                </div>

                <div class="card-body px-4 py-5">
                    
                    <div class="text-center mb-4">
                        <img src="<?php echo e($KurirData->gambar_produk ? asset('storage/' . $KurirData->gambar_produk) : 'https://via.placeholder.com/600x400?text=Tidak+Ada+Gambar'); ?>"
                             alt="Gambar Produk"
                             class="img-fluid rounded-3 shadow-sm"
                             style="max-width: 100%; height: auto;">
                    </div>

                    
                    <h4 class="card-title fw-bold text-center text-primary mb-4">
                        <?php echo e($KurirData->nama_produk); ?>

                    </h4>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <p class="mb-2"><strong>Harga:</strong></p>
                            <p class="text-muted">Rp<?php echo e(number_format($KurirData->harga_satuan, 0, ',', '.')); ?></p>
                            <p class="mb-2"><strong>Stok Tersedia:</strong></p>
                            <p class="text-muted"><?php echo e($KurirData->stok_tersedia); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <p class="mb-2"><strong>Dibuat pada:</strong></p>
                            <p class="text-muted"><?php echo e($KurirData->created_at ? $KurirData->created_at->format('d M Y H:i') : '-'); ?></p>
                            <p class="mb-2"><strong>Diupdate pada:</strong></p>
                            <p class="text-muted"><?php echo e($KurirData->updated_at ? $KurirData->updated_at->format('d M Y H:i') : '-'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="card-footer bg-light border-top text-center py-3">
                    <a href="<?php echo e(route('produk.index')); ?>"
                       class="btn btn-outline-secondary me-2 d-inline-flex align-items-center gap-1">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                    <a href="<?php echo e(route('produk.edit', $KurirData->id_produk ?? $KurirData->id)); ?>"
                       class="btn btn-primary d-inline-flex align-items-center gap-1">
                        <i class="bi bi-pencil-square"></i> Edit Produk
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/produk/profil_produk.blade.php ENDPATH**/ ?>