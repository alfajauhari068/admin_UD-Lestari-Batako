<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h2 class="mb-4 fw-bold text-primary text-center">Detail Pengiriman</h2>

    <div class="card shadow border-0 mx-auto" style="max-width: 600px; border-radius: 16px;">
        <div class="card-body p-4">
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><strong>ID Pengiriman:</strong> <?php echo e($pengiriman->id_pengiriman); ?></li>
                <li class="list-group-item"><strong>Nama Pelanggan:</strong> <?php echo e($pengiriman->pesanan->pelanggan->nama); ?></li>
                <li class="list-group-item"><strong>Alamat Pengiriman:</strong> <?php echo e($pengiriman->alamat_pengiriman); ?></li>
                <li class="list-group-item"><strong>Tanggal Pengiriman:</strong> 
                    <?php echo e($pengiriman->tanggal_pengiriman ? $pengiriman->tanggal_pengiriman->format('d M Y') : '-'); ?>

                </li>
                <li class="list-group-item"><strong>Jasa Kurir:</strong> <?php echo e($pengiriman->jasa_kurir ?? '-'); ?></li>
                <li class="list-group-item"><strong>No Resi:</strong> <?php echo e($pengiriman->no_resi ?? '-'); ?></li>
            </ul>

            <div class="d-flex justify-content-between mt-4">
                <a href="<?php echo e(route('pengiriman.edit', $pengiriman->id_pengiriman)); ?>" 
                   class="btn btn-warning rounded-pill px-4 shadow-sm">
                    <i class="bi bi-pencil-square me-1"></i> Edit
                </a>
                <a href="<?php echo e(route('pengiriman.index')); ?>" 
                   class="btn btn-secondary rounded-pill px-4 shadow-sm">
                    <i class="bi bi-arrow-left-circle me-1"></i> Kembali
                </a>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/pengiriman/detail_pengiriman.blade.php ENDPATH**/ ?>