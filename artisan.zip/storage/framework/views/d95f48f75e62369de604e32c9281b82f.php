<?php $__env->startSection('content'); ?>
    <div id="auth">
        <!-- Bagian Kiri (Form Login) -->
        <div id="auth-left">
            <div class="auth-logo text-center mb-4">
                <a href="index.html"><img src="<?php echo e(asset('template/assets/images/logo/logo.svg')); ?>" alt="Logo"></a>
            </div>
            <h1 class="auth-title text-center">Welcome Back</h1>
            <p class="auth-subtitle text-center mb-4">Please log in to your account to continue.</p>

            <form method="POST" action="<?php echo e(route('login.store')); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>
                <?php if(session()->has('login_error')): ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <?php echo e(session('login_error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                    
                <?php endif; ?>
                <div class="form-group position-relative has-icon-left mb-3">
                    <input type="email" id="email" name="email" name="prevent_autofill" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email" autocomplete="off" required>
                    <div class="form-control-icon">
                        <i class="bi bi-person"></i>
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group position-relative has-icon-left mb-3">
                    <input type="password" id="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" autocomplete="off" required>
                    <div class="form-control-icon">
                        <i class="bi bi-lock"></i>
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary btn-block btn-sm shadow-sm mt-3">Log in</button>
            </form>
            <div class="text-center mt-3">
                <p class="text-gray-600">Don't have an account? <a href="<?php echo e(route('register')); ?>" class="font-bold text-primary">Sign up</a>.</p>
            </div>
        </div>

        <!-- Bagian Kanan (Konten Tambahan) -->
        <div id="auth-right">
            <div class="text-center text-white px-5">
                <h1 class="display-6 fw-bold">Welcome to Our Platform</h1>
                <p class="fs-6">Access all features and manage your account with ease.</p>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\Semester 4\Pemrograman FrameWork\ud_lestari-batako\ud_lestari-batako\resources\views/auth/login.blade.php ENDPATH**/ ?>