<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

<p align="center">
<a href="https://github.com/laravel/framework/actions"><img src="https://github.com/laravel/framework/workflows/tests/badge.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel takes the pain out of development by easing common tasks used in many web projects, such as:

Laravel is accessible, powerful, and provides tools required for large, robust applications.

## Learning Laravel

Laravel has the most extensive and thorough [documentation](https://laravel.com/docs) and video tutorial library of all modern web application frameworks, making it a breeze to get started with the framework.

You may also try the [Laravel Bootcamp](https://bootcamp.laravel.com), where you will be guided through building a modern Laravel application from scratch.

If you don't feel like reading, [Laracasts](https://laracasts.com) can help. Laracasts contains over 2000 video tutorials on a range of topics including Laravel, modern PHP, unit testing, and JavaScript. Boost your skills by digging into our comprehensive video library.

## Laravel Sponsors

We would like to extend our thanks to the following sponsors for funding Laravel development. If you are interested in becoming a sponsor, please visit the Laravel [Patreon page](https://patreon.com/taylorotwell).

### Premium Partners

## Contributing

Thank you for considering contributing to the Laravel framework! The contribution guide can be found in the [Laravel documentation](https://laravel.com/docs/contributions).

## Code of Conduct

In order to ensure that the Laravel community is welcoming to all, please review and abide by the [Code of Conduct](https://laravel.com/docs/contributions#code-of-conduct).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
# w e b s i t e * U D * L e s t a r i _ B a t a k o 

# UD. Lestari Batako – Industrial Admin Dashboard (Laravel)

## 1. Project Overview

- Purpose: Administrative dashboard for managing product inventory, orders, and production workflows for UD. Lestari Batako.
- Target users: Admin and staff responsible for operations, inventory, and production tracking.

## 2. Core Features

- Dashboard monitoring
- Produk management
- Pesanan management
- Produksi & karyawan tracking

## 3. Tech Stack

- Laravel (detected: 10.x via composer.json)
- Blade + Bootstrap
- MySQL
- Vite

<!-- UD. Lestari Batako - Admin Dashboard README -->

# UD. Lestari Batako — Industrial Admin Dashboard

Deskripsi singkat: aplikasi dashboard admin berbasis Laravel untuk mengelola produk, pesanan, produksi, dan karyawan UD. Lestari Batako.

## Fitur Utama

- Dashboard & statistik
- Manajemen Produk (CRUD)
- Manajemen Pesanan
- Produksi & alokasi karyawan
- Tampilan admin yang disesuaikan (CSS: `public/css/admin-industrial.css`)

## Teknologi

- Laravel (PHP)
- Blade templates + Bootstrap
- Vite (asset bundling)
- Database: MySQL / MariaDB

## Persyaratan Sistem (development)

- PHP 8.0+ (disarankan 8.1+)
- Composer
- Node.js 16+ dan npm
- MySQL / MariaDB

## Persiapan dan instalasi (local)

Jalankan dari root repository:

```bash
# install PHP dependencies
composer install

# copy env dan atur kredensial DB
cp .env.example .env
php artisan key:generate

# install JS dependencies dan jalankan Vite (development)
npm install
npm run dev

# migrasi database
php artisan migrate

# (opsional) jalankan seeder jika ada
php artisan db:seed

# jalankan server lokal
php artisan serve
```

File utama layout: `resources/views/layouts/app.blade.php`

Tema/CSS utama disimpan di: `public/css/admin-industrial.css`

## Build untuk produksi

```bash
npm run build
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## Menjalankan test (jika ada)

```bash
vendor/bin/phpunit
```

## Tips deploy cepat ke GitHub (push repo)

```bash
git add .
git commit -m "chore: initial project README and setup"
git push origin main
```

Jika ingin membuat release, tambahkan tag:

```bash
git tag -a v1.0.0 -m "Initial release"
git push origin v1.0.0
```

## Catatan pengembangan dan kustomisasi

- Hindari menaruh style inline — gunakan `public/css/admin-industrial.css` sebagai sumber kebenaran tema.
- Layout utama ada di `resources/views/layouts/app.blade.php` dan `resources/views/layouts/sidebar.blade.php`.
- Banyak tampilan menggunakan komponen Blade dalam `resources/views/*`.

## Kontribusi

- Buat branch feature, lakukan perubahan, buat PR ke branch `main`.

## Lisensi

- MIT

---

Jika mau, saya bisa menambahkan bagian khusus: panduan env (`.env`), contoh seeders, atau instruksi Docker untuk development. Mau saya tambahkan salah satu sekarang?
